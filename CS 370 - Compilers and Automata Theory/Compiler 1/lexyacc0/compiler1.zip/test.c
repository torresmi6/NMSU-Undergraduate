main(){
    puts("Hello!");
    puts("Goodbye!");
}
